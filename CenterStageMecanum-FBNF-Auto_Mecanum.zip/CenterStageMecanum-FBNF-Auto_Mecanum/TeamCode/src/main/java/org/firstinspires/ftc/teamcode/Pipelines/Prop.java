package org.firstinspires.ftc.teamcode.Pipelines;

public enum Prop {
    LEFT,
    CENTER,
    RIGHT
}
