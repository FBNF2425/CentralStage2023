package org.firstinspires.ftc.teamcode.Autonomous;

public class Auto_Struct {
    enum RobotDirection
    {
       FORWARD,
       BACKWARD,
       SPINCLOCKWISE,
       SPINANTICLOCKWISE,
       RIGHT,
       LEFT,
       LEFTFRONTDIAGONAL,
       RIGHTFRONTDIAGONAL,
       LEFTBACKWARDDIAGONAL,
       RIGHTBACKWARDDIAGONAL,
       ROTATELEFTBACKPIVOT_ANTICLOCK,
       ROTATERIGHTBACKPIVOT_CLOCK,
       ROTATEBACKCENTERPIVOT_ANTICLOCK


    }
}
