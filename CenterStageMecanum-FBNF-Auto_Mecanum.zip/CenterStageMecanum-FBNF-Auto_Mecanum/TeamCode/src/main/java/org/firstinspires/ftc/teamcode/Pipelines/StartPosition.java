package org.firstinspires.ftc.teamcode.Pipelines;

public enum StartPosition {
    RED_AUD,
    RED_STAGE,
    BLUE_AUD,
    BLUE_STAGE,
    RED_STAGE_SPIKE_START
}
